package com.example.respira

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.respira.ui.theme.RespiraTheme
import java.util.concurrent.TimeUnit

class ProgressoActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RespiraTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    ProgressoScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun ProgressoScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val sharedPref = context.getSharedPreferences("app_prefs", Activity.MODE_PRIVATE)
    val startDate = sharedPref.getLong("start_date", System.currentTimeMillis())
    val days = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - startDate)
    val cigarettesNotSmoked = days * 10 // suponha 10 por dia
    val savedMoney = cigarettesNotSmoked / 5 * 2 // R$2 a cada 5 cigarros

    val beneficios = listOf(
        "🔸 Após 20 minutos: Pressão arterial normaliza.",
        "🔸 Após 8 horas: Níveis de oxigênio se estabilizam.",
        "🔸 Após 24 horas: Risco de ataque cardíaco reduz.",
        "🔸 Após 72 horas: Respiração melhora.",
        "🔸 Após 1 semana: Paladar e olfato ficam mais apurados.",
        "🔸 Após 1 mês: Tosse e falta de ar diminuem."
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🎉 Dias sem fumar: $days", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(8.dp))
        Text("💰 Dinheiro economizado: R$$savedMoney", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(8.dp))
        Text("🚭 Cigarros não fumados: $cigarettesNotSmoked", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(24.dp))

        Text("✅ Benefícios para a saúde:", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        beneficios.forEach {
            Text(text = it, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            with(sharedPref.edit()) {
                putLong("start_date", System.currentTimeMillis())
                apply()
            }
        }) {
            Text("Reiniciar contagem")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { (context as Activity).finish() }) {
            Text("Voltar")
        }
    }
}