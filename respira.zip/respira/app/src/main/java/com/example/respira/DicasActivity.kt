package com.example.respira

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight

class DicasActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DicasScreen()
        }
    }
}

@Composable
fun DicasScreen() {
    val context = LocalContext.current

    val dicas = listOf(
        "🚶‍♂️ Caminhar por 15 minutos reduz a vontade de fumar.",
        "💧 Beba água quando sentir vontade de fumar.",
        "📊 Estudos mostram que após 20 minutos sem fumar, sua pressão arterial já começa a normalizar.",
        "🌬️ Em 3 dias sem cigarro, a respiração melhora consideravelmente.",
        "🧘 Técnicas de respiração profunda podem ajudar nos momentos de ansiedade.",
        "📚 Um estudo da OMS indica que pessoas com apoio psicológico têm 50% mais chances de parar de fumar."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Título
        Text(
            text = "💡 Dicas Aleatórias",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Lista de dicas
        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(dicas) { dica ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFDFFFE2)
                    )
                ) {
                    Text(
                        text = dica,
                        modifier = Modifier.padding(12.dp),
                        fontSize = 16.sp
                    )
                }
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

        // Botão de voltar
        Button(
            onClick = {
                val intent = Intent(context, MainActivity::class.java)
                context.startActivity(intent)
            },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Voltar")
        }
    }
}
